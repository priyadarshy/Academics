%% Ultrasound Homework Task 2 Calling File
% Calls the function that does the task 2 stuff

% calls the function twice for different windows. 
UltrasoundHomework_Task2(1);